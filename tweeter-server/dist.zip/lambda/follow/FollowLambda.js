"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const FollowService_1 = require("../../model/service/FollowService");
const handler = async (req) => {
    const followService = new FollowService_1.FollowService();
    const [followerCount, followingCount] = await followService.follow(req.authToken, req.userToFollow);
    return {
        success: true,
        message: null,
        followerCount: followerCount,
        followeeCount: followingCount
    };
};
exports.handler = handler;
