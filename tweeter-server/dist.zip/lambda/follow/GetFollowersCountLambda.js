"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const FollowService_1 = require("../../model/service/FollowService");
const handler = async (req) => {
    const followService = new FollowService_1.FollowService();
    const followerCount = await followService.getFollowerCount(req.authToken, req.user);
    return {
        success: true,
        message: null,
        followerCount: followerCount
    };
};
exports.handler = handler;
