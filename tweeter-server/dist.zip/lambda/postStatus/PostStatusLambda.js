"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const PostStatusService_1 = require("../../model/service/PostStatusService");
const handler = async (req) => {
    const postStatusService = new PostStatusService_1.PostStatusService();
    await postStatusService.postStatus(req.authToken, req.newStatus);
    return {
        success: true,
        message: null
    };
};
exports.handler = handler;
