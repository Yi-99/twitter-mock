"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Dao = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
class Dao {
    tableName = "Follows";
    indexName = "follows_index";
    follower_handle = "follower_handle";
    followee_handle = "followee_handle";
    static client;
    constructor() { }
    // Singleton pattern
    static getInstance() {
        if (!Dao.client) {
            Dao.client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({ region: 'us-east-1' }));
        }
        return Dao.client;
    }
}
exports.Dao = Dao;
