"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DaoFactory = void 0;
const FollowDao_1 = require("./FollowDao");
const PostStatusDao_1 = require("./PostStatusDao");
const S3Dao_1 = require("./S3Dao");
const SessionDao_1 = require("./SessionDao");
const StatusDao_1 = require("./StatusDao");
const UserDao_1 = require("./UserDao");
class DaoFactory {
    static getDao(type) {
        if (type === 'user') {
            return new UserDao_1.UserDao();
        }
        else if (type === 's3') {
            return new S3Dao_1.S3Dao();
        }
        else if (type === 'status') {
            return new StatusDao_1.StatusDao();
        }
        else if (type === 'postStatus') {
            return new PostStatusDao_1.PostStatusDao();
        }
        else if (type === 'session') {
            return new SessionDao_1.SessionDao();
        }
        else if (type === 'follow') {
            return new FollowDao_1.FollowDao();
        }
        else {
            throw new Error('Invalid DAO type');
        }
    }
}
exports.DaoFactory = DaoFactory;
