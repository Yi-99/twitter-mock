"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowDao = void 0;
const Dao_1 = require("./Dao");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class FollowDao extends Dao_1.Dao {
    constructor() {
        super();
        this.tableName = "follows";
    }
    get() {
        throw new Error("Method not implemented.");
    }
    post() {
        throw new Error("Method not implemented.");
    }
    delete() {
        throw new Error("Method not implemented.");
    }
    update() {
        throw new Error("Method not implemented.");
    }
    client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({ region: 'us-west-1' }));
    async loadFollowers(lastItemAlias, pageSize, userAlias) {
        const input = {
            TableName: this.tableName,
            KeyConditionExpression: `follower_handle = :handle`,
            ExpressionAttributeValues: {
                ":handle": { "S": userAlias },
            },
            Limit: pageSize,
            ExclusiveStartKey: lastItemAlias
                ? {
                    [this.follower_handle]: { "S": userAlias },
                    [this.followee_handle]: { "S": lastItemAlias }
                }
                : undefined,
        };
        const response = await Dao_1.Dao.getInstance().send(new client_dynamodb_1.QueryCommand(input));
        const followers = response.Items;
        console.log("Followers:", followers);
        return {
            items: followers,
            hasNextPage: !!response.LastEvaluatedKey
        };
    }
    async loadFollowees(lastItemAlias, pageSize, userAlias) {
        const input = {
            TableName: this.tableName,
            IndexName: this.indexName,
            KeyConditionExpression: `followee_handle = :handle`,
            ExpressionAttributeValues: {
                ":handle": { "S": userAlias },
            },
            Limit: pageSize,
            ExclusiveStartKey: lastItemAlias
                ? {
                    [this.follower_handle]: { "S": lastItemAlias },
                    [this.followee_handle]: { "S": userAlias }
                }
                : undefined,
        };
        const response = await Dao_1.Dao.getInstance().send(new client_dynamodb_1.QueryCommand(input));
        const followees = response.Items;
        console.log("Followees:", followees);
        return {
            items: followees,
            hasNextPage: !!response.LastEvaluatedKey
        };
    }
    async follow(alias, userToFollow) {
        const params = {
            TableName: this.tableName,
            Item: {
                [this.follower_handle]: '@' + alias,
                [this.followee_handle]: userToFollow.alias,
                "follower_name": alias,
                "followee_name": userToFollow.alias,
            }
        };
        const response = await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.PutCommand(params));
        return response.$metadata.httpStatusCode === 200;
    }
    async unfollow(alias, userToUnfollow) {
        const params = {
            TableName: this.tableName,
            Key: {
                [this.follower_handle]: '@' + alias,
                [this.followee_handle]: userToUnfollow.alias,
                "follower_name": alias,
                "followee_name": userToUnfollow.alias,
            },
        };
        const response = await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.DeleteCommand(params));
        return response.$metadata.httpStatusCode === 200;
    }
    async getIsFollowerStatus(userAlias, selectedUserAlias) {
        const params = {
            TableName: this.tableName,
            Key: {
                [this.follower_handle]: userAlias,
                [this.followee_handle]: selectedUserAlias,
            },
        };
        const response = await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.GetCommand(params));
        return response.Item !== undefined;
    }
    async getFolloweeCount(user) {
        const params = {
            TableName: "users",
            Key: {
                "alias": user.alias,
            }
        };
        const response = await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.GetCommand(params));
        return response.Item?.followingCount;
    }
    async getFollowerCount(user) {
        const params = {
            TableName: "users",
            Key: {
                "alias": user.alias,
            }
        };
        const response = await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.GetCommand(params));
        return response.Item?.followerCount;
    }
    async getFollowers(alias) {
        console.log("getFollowers");
        const params = {
            TableName: this.tableName,
            KeyConditionExpression: `follower_handle = :handle`,
            ExpressionAttributeValues: {
                ":handle": { "S": alias },
            },
            ProjectionExpression: "followee_handle"
        };
        try {
            const response = await Dao_1.Dao.getInstance().send(new client_dynamodb_1.QueryCommand(params));
            if (!response.Items || response.Items.length === 0) {
                console.log(`No followers found for alias: ${alias}`);
                return [];
            }
            if (!response.Items) {
                return [];
            }
            const followers = response.Items.map((item) => item["followee_handle"]);
            return followers;
        }
        catch (error) {
            console.error("Error fetching receivers for follower:", error);
            throw new Error("Unable to fetch followers");
        }
    }
}
exports.FollowDao = FollowDao;
