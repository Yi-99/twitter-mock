"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostStatusDao = void 0;
const Dao_1 = require("./Dao");
class PostStatusDao extends Dao_1.Dao {
    constructor() {
        super();
    }
    get() {
        throw new Error("Method not implemented.");
    }
    post() {
        throw new Error("Method not implemented.");
    }
    delete() {
        throw new Error("Method not implemented.");
    }
    update() {
        throw new Error("Method not implemented.");
    }
}
exports.PostStatusDao = PostStatusDao;
