"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3Dao = void 0;
const Dao_1 = require("./Dao");
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
class S3Dao extends Dao_1.Dao {
    s3Client;
    constructor() {
        super();
        this.s3Client = new client_s3_1.S3Client({ region: "us-east-1" });
    }
    get() {
        throw new Error("Method not implemented.");
    }
    post() {
        throw new Error("Method not implemented");
    }
    async upload(imageStringBase64) {
        const key = `images/${new Date().getTime()}.png`;
        const fileContent = Buffer.from(imageStringBase64, "base64");
        try {
            const params = {
                Body: fileContent,
                Bucket: "cs340f2024",
                Key: key,
            };
            const command = new client_s3_1.PutObjectCommand(params);
            const response = await this.s3Client.send(command);
            console.log("File upload successful with ", response.$metadata.httpStatusCode);
            const getParams = {
                Bucket: "cs340f2024",
                Key: key,
            };
            const url = await (0, s3_request_presigner_1.getSignedUrl)(this.s3Client, new client_s3_1.GetObjectCommand(getParams), { expiresIn: 3600 });
            return url;
        }
        catch (error) {
            throw new Error("S3 upload failed with: " + error);
        }
    }
    delete() {
        throw new Error("Method not implemented.");
    }
    update() {
        throw new Error("Method not implemented.");
    }
}
exports.S3Dao = S3Dao;
