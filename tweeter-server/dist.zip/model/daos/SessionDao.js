"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionDao = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const Dao_1 = require("./Dao");
const uuid_1 = require("uuid");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const tweeter_shared_1 = require("tweeter-shared");
class SessionDao extends Dao_1.Dao {
    constructor() {
        super();
        // this.tableName = "session";
        this.tableName = "sessions";
    }
    client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({ region: "us-east-1" }));
    get() {
        throw new Error("Method not implemented.");
    }
    post() {
        throw new Error("Method not implemented.");
    }
    delete() {
        throw new Error("Method not implemented.");
    }
    update() {
        throw new Error("Method not implemented.");
    }
    async getSession(authToken) {
        const params = {
            TableName: this.tableName,
            Key: {
                "auth_token": authToken
            }
        };
        try {
            const response = await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.GetCommand(params));
            return response.Item;
        }
        catch (error) {
            throw new Error("Failed to get session with: " + error);
        }
    }
    async updateSession(authToken, timestamp) {
        try {
            const params = {
                TableName: this.tableName,
                Key: {
                    "auth_token": authToken
                },
                ExpressionAttributeNames: {
                    "#timestamp": "timestamp"
                },
                ExpressionAttributeValues: {
                    ":timestamp": timestamp,
                },
                UpdateExpression: "SET #timestamp = :timestamp"
            };
            await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.UpdateCommand(params));
        }
        catch (error) {
            throw new Error("Failed to update session with: " + error);
        }
    }
    async createSession(alias) {
        const session = {
            "auth_token": (0, uuid_1.v4)(),
            "timestamp": Math.floor(Date.now() / 1000) + 3600,
            "alias": alias
        };
        const params = {
            TableName: this.tableName,
            Item: session
        };
        try {
            await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.PutCommand(params));
            return new tweeter_shared_1.AuthToken(session.auth_token, session.timestamp);
        }
        catch (error) {
            throw new Error("Failed to create session with: " + error);
        }
    }
}
exports.SessionDao = SessionDao;
