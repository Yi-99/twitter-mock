"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusDao = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const Dao_1 = require("./Dao");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class StatusDao extends Dao_1.Dao {
    constructor() {
        super();
        this.tableName = "statuses";
    }
    get() {
        throw new Error("Method not implemented.");
    }
    post() {
        throw new Error("Method not implemented.");
    }
    delete() {
        throw new Error("Method not implemented.");
    }
    update() {
        throw new Error("Method not implemented.");
    }
    async getStoryItems(alias, pageSize, timestamp) {
        const params = {
            TableName: this.tableName,
            KeyConditionExpression: "author_alias = :authorAlias",
            ExpressionAttributeValues: {
                ":authorAlias": { "S": alias }
            },
            Limit: pageSize,
            ExclusiveStartKey: timestamp
                ? { author_alias: { "S": alias }, timestamp: { "N": timestamp } }
                : undefined,
            ScanIndexForward: false,
        };
        try {
            const response = await Dao_1.Dao.getInstance().send(new client_dynamodb_1.QueryCommand(params));
            const stories = response.Items;
            return {
                items: stories || [],
                hasNextPage: !!response.LastEvaluatedKey
            };
        }
        catch (error) {
            console.error("Error retrieving story:", error);
            throw error;
        }
    }
    async getFeedItems(alias, pageSize, timestamp) {
        const params = {
            TableName: this.tableName,
            KeyConditionExpression: "author_alias = :authorAlias",
            ExpressionAttributeValues: {
                ":authorAlias": { "S": alias }
            },
            Limit: pageSize,
            ExclusiveStartKey: timestamp
                ? { author_alias: { "S": alias }, timestamp: { "N": timestamp } }
                : undefined,
            ScanIndexForward: false,
        };
        try {
            const response = await Dao_1.Dao.getInstance().send(new client_dynamodb_1.QueryCommand(params));
            const feeds = response.Items;
            return {
                items: feeds || [],
                hasNextPage: !!response.LastEvaluatedKey
            };
        }
        catch (error) {
            console.error("Error retrieving feed:", error);
            throw error;
        }
    }
    async saveStatus(post, alias, timestamp) {
        const params = {
            TableName: this.tableName,
            Item: {
                "author_alias": alias,
                "timestamp": timestamp,
                "post": post
            }
        };
        try {
            await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.PutCommand(params));
        }
        catch (error) {
            console.error("Error saving status:", error);
            throw error;
        }
    }
    async addStatusToFeeds(user, timestamp, post, followers) {
        console.log("addStatusToFeeds");
        this.tableName = "feeds";
        const requests = followers.map((follower) => ({
            PutRequest: {
                Item: {
                    "author_alias": follower.S,
                    "timestamp": timestamp.toString(),
                    "post": post,
                    "author_first_name": user.firstName,
                    "author_last_name": user.lastName,
                    "author_imageUrl": user.imageUrl,
                }
            }
        }));
        const params = {
            RequestItems: {
                [this.tableName]: requests
            }
        };
        try {
            await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.BatchWriteCommand(params));
            console.log("Status added to feeds!");
        }
        catch (error) {
            console.error("Error adding status to feed:", error);
            throw error;
        }
    }
}
exports.StatusDao = StatusDao;
