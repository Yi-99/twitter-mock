"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusDao = void 0;
const Dao_1 = require("./Dao");
class StatusDao extends Dao_1.Dao {
    constructor() {
        super();
    }
    get() {
        throw new Error("Method not implemented.");
    }
    post() {
        throw new Error("Method not implemented.");
    }
    delete() {
        throw new Error("Method not implemented.");
    }
    update() {
        throw new Error("Method not implemented.");
    }
}
exports.StatusDao = StatusDao;
