"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserDao = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const Dao_1 = require("./Dao");
const tweeter_shared_1 = require("tweeter-shared");
const bcryptjs_1 = require("bcryptjs");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
class UserDao extends Dao_1.Dao {
    constructor() {
        super();
        this.tableName = "users";
    }
    client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({ region: "us-east-1" }));
    get() {
        throw new Error("Method not implemented.");
    }
    post() {
        throw new Error("Method not implemented.");
    }
    delete() {
        throw new Error("Method not implemented.");
    }
    update() {
        throw new Error("Method not implemented.");
    }
    async login(alias, password) {
        const params = {
            TableName: this.tableName,
            Key: {
                "alias": alias
            }
        };
        const response = await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.GetCommand(params));
        if (response.Item != undefined) {
            // check if the password is correct
            if (await (0, bcryptjs_1.compare)(password, response.Item.password)) {
                return response.Item;
            }
            else {
                throw new Error("Incorrect password!");
            }
        }
        else {
            throw new Error("No user with that username!");
        }
    }
    async register(firstName, lastName, alias, password, imageUrl) {
        const params = {
            TableName: this.tableName,
            Item: {
                "alias": alias,
                "password": password,
                "firstName": firstName,
                "lastName": lastName,
                "imageUrl": imageUrl,
                "followerCount": 0,
                "followingCount": 0
            }
        };
        try {
            const response = await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.PutCommand(params));
            if (response.$metadata.httpStatusCode === 200) {
                const user = new tweeter_shared_1.User(alias, firstName, lastName, imageUrl);
                return user;
            }
            else {
                throw new Error('Error registering user');
            }
        }
        catch (error) {
            throw new Error('Error registering user');
        }
    }
    async getUser(alias) {
        const params = {
            TableName: this.tableName,
            Key: {
                "alias": alias,
            }
        };
        const response = await this.client.send(new lib_dynamodb_1.GetCommand(params));
        if (response.Item != undefined) {
            return response.Item;
        }
    }
    async updateCount(val, attributeName, num) {
        const params = {
            TableName: this.tableName,
            Key: {
                alias: val
            },
            UpdateExpression: `SET ${attributeName} = if_not_exists(${attributeName}, :start) + :change`,
            ExpressionAttributeValues: {
                ":start": 0,
                ":change": num,
            },
            ReturnValues: "ALL_NEW",
        };
        const response = await Dao_1.Dao.getInstance().send(new lib_dynamodb_1.UpdateCommand(params));
        console.log("UpdateCount:", response);
        return response.Attributes;
    }
}
exports.UserDao = UserDao;
