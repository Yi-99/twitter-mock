"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const DaoFactory_1 = require("../daos/DaoFactory");
class FollowService {
    dao;
    sessionDao;
    userDao;
    constructor() {
        this.dao = DaoFactory_1.DaoFactory.getDao('follow');
        this.sessionDao = DaoFactory_1.DaoFactory.getDao('session');
        this.userDao = DaoFactory_1.DaoFactory.getDao('user');
    }
    async validateSession(token) {
        const session = await this.sessionDao.getSession(token);
        if (!session) {
            throw new Error("Invalid auth token!");
        }
        const now = Math.floor(Date.now() / 1000);
        console.log("now:", now);
        console.log("session timestamp:", session.timestamp);
        if (now > session.timestamp) {
            throw new Error("Auth token expired!");
        }
        await this.sessionDao.updateSession(token, now + 3600);
        return session;
    }
    async loadMoreFollowers(authToken, userAlias, pageSize, lastItem) {
        await this.validateSession(authToken);
        const response = await this.dao.loadFollowers(lastItem?._alias, pageSize, userAlias);
        const users = response.items.map((item) => {
            const nameParts = item.follower_name.split(" ");
            const firstName = nameParts[0] || "";
            const lastName = nameParts.slice(1).join(" ") || "";
            return {
                _alias: item.follower_handle,
                _firstName: firstName,
                _lastName: lastName,
                _imageUrl: item.followerUrl,
            };
        });
        return [users, response.hasNextPage];
    }
    ;
    async loadMoreFollowees(authToken, userAlias, pageSize, lastItem) {
        await this.validateSession(authToken);
        const response = await this.dao.loadFollowees(lastItem?._alias, pageSize, userAlias);
        const users = response.items.map((item) => {
            const nameParts = item.followee_name.split(" ");
            const firstName = nameParts[0] || "";
            const lastName = nameParts.slice(1).join(" ") || "";
            return {
                _alias: item.followee_handle,
                _firstName: firstName,
                _lastName: lastName,
                _imageUrl: item.followeeUrl,
            };
        });
        return [users, response.hasNextPage];
    }
    ;
    async unfollow(authToken, userToUnfollow) {
        const session = await this.validateSession(tweeter_shared_1.AuthToken.fromDto(authToken).token);
        const user = await this.userDao.updateCount(session.alias, 'followingCount', -1);
        await this.userDao.updateCount(userToUnfollow._alias, 'followerCount', -1);
        await this.dao.unfollow(session.alias, tweeter_shared_1.User.fromDto(userToUnfollow));
        const followerCount = await this.getFollowerCount(authToken, userToUnfollow);
        const followingCount = await this.getFolloweeCount(authToken, userToUnfollow);
        console.log("followerCount:", followerCount);
        console.log("followingCount:", followingCount);
        console.log("user count:", user?.followerCount, user?.followingCount);
        return [followerCount, followingCount];
    }
    ;
    async follow(authToken, userToFollow) {
        const session = await this.validateSession(tweeter_shared_1.AuthToken.fromDto(authToken).token);
        const user = await this.userDao.updateCount(session.alias, 'followingCount', 1);
        await this.userDao.updateCount(userToFollow._alias, 'followerCount', 1);
        await this.dao.follow(session.alias, tweeter_shared_1.User.fromDto(userToFollow));
        const followerCount = await this.getFollowerCount(authToken, userToFollow);
        const followingCount = await this.getFolloweeCount(authToken, userToFollow);
        console.log("followerCount:", followerCount);
        console.log("followingCount:", followingCount);
        console.log("user count:", user?.followerCount, user?.followingCount);
        return [followerCount, followingCount];
    }
    ;
    async getIsFollowerStatus(authToken, user, selectedUser) {
        // TODO: Replace with the result of calling server
        return tweeter_shared_1.FakeData.instance.isFollower();
    }
    ;
    async getFolloweeCount(authToken, user) {
        const response = await this.userDao.getUser(user._alias);
        if (!response) {
            throw new Error("Invalid user");
        }
        else {
            return response.followerCount;
        }
    }
    ;
    async getFollowerCount(authToken, user) {
        const response = await this.userDao.getUser(user._alias);
        if (!response) {
            throw new Error("Invalid user");
        }
        else {
            return response.followingCount;
        }
    }
    ;
}
exports.FollowService = FollowService;
