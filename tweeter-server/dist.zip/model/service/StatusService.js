"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const DaoFactory_1 = require("../daos/DaoFactory");
class StatusService {
    dao;
    constructor() {
        this.dao = DaoFactory_1.DaoFactory.getDao('status');
    }
    async loadMoreFeedItems(authToken, userAlias, pageSize, lastItem) {
        // TODO: Replace with the result of calling server
        return this.getFakeData(lastItem, pageSize);
    }
    ;
    async loadMoreStoryItems(authToken, userAlias, pageSize, lastItem) {
        // TODO: Replace with the result of calling server
        return this.getFakeData(lastItem, pageSize);
    }
    ;
    async getFakeData(lastItem, pageSize) {
        const [statuses, hasMore] = tweeter_shared_1.FakeData.instance.getPageOfStatuses(tweeter_shared_1.Status.fromDto(lastItem), pageSize);
        const dtos = statuses.map((status) => status.dto);
        return [dtos, hasMore];
    }
}
exports.StatusService = StatusService;
