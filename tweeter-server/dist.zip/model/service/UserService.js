"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const DaoFactory_1 = require("../daos/DaoFactory");
const bcryptjs_1 = require("bcryptjs");
const uuid_1 = require("uuid");
class UserService {
    userDao;
    s3Dao;
    sessionDao;
    constructor() {
        this.userDao = DaoFactory_1.DaoFactory.getDao('user');
        this.s3Dao = DaoFactory_1.DaoFactory.getDao('s3');
        this.sessionDao = DaoFactory_1.DaoFactory.getDao('session');
    }
    async login(alias, password) {
        const user = await this.userDao.login(alias, password);
        if (user === null || user === undefined) {
            throw new Error("Invalid alias or password");
        }
        const authToken = new tweeter_shared_1.AuthToken((0, uuid_1.v4)(), Math.floor((new Date().getTime() + 3600 * 1000) / 1000));
        await this.sessionDao.createSession(alias, authToken.token, authToken.timestamp);
        return [user.dto, authToken.dto];
    }
    ;
    async register(firstName, lastName, alias, password, imageStringBase64) {
        const existingUser = await this.userDao.getUser(alias);
        if (existingUser && existingUser.alias === alias) {
            throw new Error("User already exists!");
        }
        const imageUrl = await this.s3Dao.upload(imageStringBase64);
        if (imageUrl == null) {
            throw new Error("Image not properly saved!");
        }
        const hashedPassword = await (0, bcryptjs_1.hash)(password, 10);
        const response = await this.userDao.register(firstName, lastName, alias, hashedPassword, imageUrl);
        const authToken = new tweeter_shared_1.AuthToken((0, uuid_1.v4)(), Math.floor((new Date().getTime() + 3600 * 1000) / 1000));
        await this.sessionDao.createSession(alias, authToken.token, authToken.timestamp);
        if (response === null) {
            throw new Error("Invalid registration");
        }
        return [response.dto, authToken.dto];
    }
    ;
    async getUser(alias) {
        const user = await this.userDao.getUser(alias);
        if (user == null) {
            throw new Error("User does not exist!");
        }
        return user.dto;
    }
    ;
    async logout(authToken) {
        console.log("authToken in logout:", authToken);
        const session = await this.sessionDao.getSession(authToken);
        if (session == undefined) {
            throw new Error("Token not found!");
        }
        try {
            await this.sessionDao.deleteSession(session.auth_token);
            console.log("user logged out successfully!");
            return;
        }
        catch (error) {
            throw new Error("Failed to log out user: " + error);
        }
    }
    ;
}
exports.UserService = UserService;
